kill @s
return fail